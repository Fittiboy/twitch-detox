"""Automatic Twitch moderation tool to filter out toxicity and harassment."""
# __init__.py

__version__ = "0.0.0"
